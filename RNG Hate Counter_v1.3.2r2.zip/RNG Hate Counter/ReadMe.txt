This add-on will track all kills you do and outputs them in the chat if selected or shows a list will all tracked kills.
/killcount <enemy> will output in the chat, the amount of kills on enemy
/killcount will open UI with all kills

Disclaimer: Does only track kills, where the player does the final blow. Being part of the killing does not count.

Legal Stuff:
This Add-on is not created by, affiliated with or sponsored by ZeniMax Media Inc. or its affiliates. 
The Elder Scrolls® and related logos are registered trademarks or trademarks of ZeniMax Media Inc. in the United States and/or other countries. All rights reserved.